import React, {ChangeEvent, ChangeEventHandler, KeyboardEvent, useState} from 'react';
import {FilterValuesType} from './App';
import {FullInput} from "./components/FullInput";
import {Input} from "./components/Input";
import {Button} from "./components/Button";
import {ControlButtons} from './components/ControlButtons'

type TaskType = {
    id: string
    title: string
    isDone: boolean
}

type PropsType = {
    filter: FilterValuesType
    title: string
    tasks: Array<TaskType>
    removeTask: (taskId: string) => void
    changeFilter: (value: FilterValuesType) => void
    addTask: (title: string) => void
    changeTaskStatus: (id: string, isDone: boolean) => void
}

export function Todolist(props: PropsType) {

    let [title, setTitle] = useState("")
    // console.log(title)

    let [error, setError] = useState(false)

    const ErrorMessage = error
        ? <div style={{backgroundColor: "red", color: "white"}}>Title is required</div>
        : null

    const addTask = () => {
        const trimmedTitle = title.trim()
        if (trimmedTitle) {
            props.addTask(trimmedTitle);
            setTitle("");
        } else {
            setError(true)
        }
    }

    return <div>
        <h3>{props.title}
            <div className={"filter-type"}>{props.filter}</div>
        </h3>
        <span className={error ? 'error' : ''}>
            <Input title={title} setTitle={setTitle}/>
        </span>
        <Button name={'+'} callback={() => {
            addTask()
        }}/>
        {ErrorMessage}
        <ul>
            {
                props.tasks.map(t => {

                    const onClickHandler = () => props.removeTask(t.id)

                    const onChangeHandler = (e:ChangeEvent<HTMLInputElement>) =>{
                        props.changeTaskStatus(t.id, e.currentTarget.checked)
                        // console.log(e.currentTarget.checked)
                    }
                    const taskClass = t.isDone ? "completed-task" : ""

                    return <li key={t.id}>
                        <input onChange={onChangeHandler} type="checkbox"
                               checked={t.isDone}/>
                        <span className={taskClass}>{t.title}</span>
                        <button onClick={onClickHandler}>x</button>
                    </li>
                })
            }
        </ul>
        {/*<div>*/}
        {/*    <button onClick={ onAllClickHandler }>All</button>*/}
        {/*    <button onClick={ onActiveClickHandler }>Active</button>*/}
        {/*    <button onClick={ onCompletedClickHandler }>Completed</button>*/}
        {/*</div>*/}

        <ControlButtons filter={props.filter} changeFilter={props.changeFilter}/>
    </div>
}
