import React from 'react';
import {FilterValuesType} from "../App";

type ControlButtonsType = {
    filter: FilterValuesType
    changeFilter:(filter: FilterValuesType)=>void

}

export const ControlButtons = (props: ControlButtonsType) => {

    // const onAllClickHandler = () => props.changeFilter("all");
    // const onActiveClickHandler = () => props.changeFilter("active");
    // const onCompletedClickHandler = () => props.changeFilter("completed");

    const onClickHandler = (filter:FilterValuesType)=>{
        return props.changeFilter(filter)
    }

    return (
        <div>
            <button className={props.filter==='all'?"button-active":""}
                    onClick={()=>{onClickHandler("all")}}>All</button>
            <button className={props.filter==='active'?"button-active":""}
                    onClick={ ()=>{onClickHandler("active")} }>Active</button>
            <button className={props.filter==='completed'?"button-active":""}
                    onClick={ ()=>{onClickHandler("completed")} }>Completed</button>
        </div>
    )
};

